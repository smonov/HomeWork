a = input("Write your first name please: ")
b = input("Write your surname please: ")
c = input("Write your last-name please: ")

print ( a, b, c )
